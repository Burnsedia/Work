---
name: Bug report
about: Report a bug in Godot
title: ''
labels: ''
assignees: ''

---

**Godot version:**

**OS/device including version:**

**Issue description:**

**Steps to reproduce:**

**Minimal reproduction project:**
