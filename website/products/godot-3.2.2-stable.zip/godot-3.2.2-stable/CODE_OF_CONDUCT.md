# Code of Conduct

By participating in this repository, you agree to abide by the
[Godot Engine Code of Conduct](https://godotengine.org/code-of-conduct).
